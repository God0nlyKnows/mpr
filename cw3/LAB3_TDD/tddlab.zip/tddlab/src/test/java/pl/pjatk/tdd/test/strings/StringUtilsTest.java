package pl.pjatk.tdd.test.strings;

public class StringUtilsTest {

}
