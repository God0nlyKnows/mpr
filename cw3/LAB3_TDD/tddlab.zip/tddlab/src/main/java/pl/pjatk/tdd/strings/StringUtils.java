package pl.pjatk.tdd.strings;

public class StringUtils {
}
