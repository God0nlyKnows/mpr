package pl.pjatk.tdd.arrays;

public class ArraysStatistics {
    public static int max(int[] numbers){
        return 0;
    }

    public static int min(int[] numbers){
        return 0;
    }

    public static double avg(int[] numbers){
        return 0;
    }

    public static int sum(int[] numbers){
        return 0;
    }
}
