package pl.pjatk.unit_tests;

public class Square extends Rectangle {
    public Square(int a) {
        super(a, a);
    }
}
